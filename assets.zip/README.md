# ricardohenrique.divshot.io
### Este é um site pessoal onde exponho:

  - Uma descrição minha
  - Meus conhecimentos
  - Meu currículo
  - O que desejo aprender no futuro
  - Formas de contato
  - Meu portfólio de projetos
  - Meus perfis em outras redes
  
### Versão

1.0

